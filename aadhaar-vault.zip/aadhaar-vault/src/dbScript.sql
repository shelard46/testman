create table AADHAAR_VAULT (
AADHAAR_NUMBER VARCHAR2(1000 BYTE),
REFERENCE_KEY VARCHAR2(1000 BYTE)
);

create index aadhaar_num_index on aadhaar_vault(aadhaar_number);
create index ref_key_index on aadhaar_vault(reference_key);