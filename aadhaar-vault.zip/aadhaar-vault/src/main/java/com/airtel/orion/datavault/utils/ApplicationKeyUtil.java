package com.airtel.orion.datavault.utils;

import java.util.Map;

public class ApplicationKeyUtil {

	private static Map<String, String> applicationKeys;

	public static Map<String, String> getApplicationKeys() {
		return applicationKeys;
	}

	public static void setApplicationKeys(Map<String, String> applicationKeys) {
		ApplicationKeyUtil.applicationKeys = applicationKeys;
	}

	public static String getAPIkey(String key) {
		return applicationKeys.get(key);
	}

}
