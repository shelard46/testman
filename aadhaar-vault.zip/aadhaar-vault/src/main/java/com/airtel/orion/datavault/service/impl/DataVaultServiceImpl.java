package com.airtel.orion.datavault.service.impl;

import com.airtel.orion.datavault.constants.DataVaultConstants;
import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.dao.AadhaarVaultDAO;
import com.airtel.orion.datavault.dto.AadhaarVaultTO;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import com.airtel.orion.datavault.request.AadhaarNumberRequest;
import com.airtel.orion.datavault.request.ReferenceKeyRequest;
import com.airtel.orion.datavault.response.ResponseDTO;
import com.airtel.orion.datavault.service.CipherService;
import com.airtel.orion.datavault.service.DataVaultService;
import com.airtel.orion.datavault.utils.AadhaarValidator;
import com.airtel.orion.datavault.utils.AlgorithmUtils;
import com.airtel.orion.datavault.utils.CommonUtil;
import com.airtel.orion.datavault.utils.ReferenceKeyValidator;
import com.airtel.orion.datavault.utils.ReferenceMaskUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * @author Mithil
 *
 */
@Service
public class DataVaultServiceImpl implements DataVaultService {

	@Autowired
	private AadhaarVaultDAO vaultDao;

	@Autowired
	private CipherService cipherService;

	@Value("${hsm.encryption.enable}")
	private String hsmEncryptionEnabled;

	private static final long NUMBER_LIMIT = 99999999999L;

	private static final long CANTOR_NUMBER_GENERATOR = 212129;

	private static final Logger LOGGER = LoggerFactory.getLogger(DataVaultServiceImpl.class);

	@Override
	public String getAadhaarNumber(AadhaarNumberRequest request) throws DataVaultRuntimeException {
		String refKey = request.getReferenceKey();
		ReferenceKeyValidator.validateReferenceKey(refKey);
		if (hsmEncryptionEnabled != null && hsmEncryptionEnabled.equalsIgnoreCase("true")) {
			String encryptedRefKey = cipherService.encrypt(refKey);
			AadhaarVaultTO aadhaarVaultTO = vaultDao.getAadhaarVaultData(encryptedRefKey);
			validateAadhaarVaultData(refKey, encryptedRefKey, aadhaarVaultTO);
			return cipherService.decrypt(aadhaarVaultTO.getUid());
		} else {
			AadhaarVaultTO aadhaarVaultTO = vaultDao.getAadhaarVaultData(refKey);
			validateAadhaarVaultData(refKey, null, aadhaarVaultTO);
			return aadhaarVaultTO.getUid();
		}
	}

	private void validateAadhaarVaultData(String refKey, String encryptedRefKey, AadhaarVaultTO aadhaarVaultTO) {
		if (null == aadhaarVaultTO) {
			LOGGER.error("No Aadhaar Number found for the reference Key :{}:", ReferenceMaskUtil.maskPlainReferenceKeyForLog(refKey), ReferenceMaskUtil.maskEncryptedReferenceKeyForLog(encryptedRefKey));
			throw new DataVaultRuntimeException(ResponseErrorCode.INVALID_REF_KEY_NO_MAPPING, "Aadhaar Mapping not found");
		}

		if (StringUtils.isEmpty(aadhaarVaultTO.getUid())) {
			LOGGER.error("Aadhaar Number is already deleted for the referenceKey - :{}: | EncryptedRefKey - :{}: ", ReferenceMaskUtil.maskPlainReferenceKeyForLog(refKey), ReferenceMaskUtil.maskEncryptedReferenceKeyForLog(encryptedRefKey));
			throw new DataVaultRuntimeException(ResponseErrorCode.AADHAAR_HAS_BEEN_DELETED, "Aadhaar Mapping not found");
		}
	}

	@Override
	public String getReferenceKey(ReferenceKeyRequest request) throws DataVaultRuntimeException {
		String refKey = null;
		String uid = request.getUid();
		AadhaarValidator.validateAadhaarNumber(uid);

		if(hsmEncryptionEnabled != null && hsmEncryptionEnabled.equalsIgnoreCase("true")) {
			String encryptedUid = cipherService.encrypt(uid);
			String encryptedRefKey = vaultDao.getReferenceKey(encryptedUid);
			if (StringUtils.isEmpty(encryptedRefKey)) {
				AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
				refKey = generateUniqueRefKey();
				encryptedRefKey = cipherService.encrypt(refKey);
				aadhaarVaultTO.setUid(encryptedUid);
				aadhaarVaultTO.setReferenceKey(encryptedRefKey);
				vaultDao.createRefKeyToAadhaarMapping(aadhaarVaultTO);
			} else {
				refKey = cipherService.decrypt(encryptedRefKey);
			}
		} else {
			//String encryptedUid = cipherService.encrypt(uid);
			refKey = vaultDao.getReferenceKey(uid);
			if (refKey == null) {
				AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
				refKey = generateUniqueRefKey();
				//encryptedRefKey = cipherService.encrypt(refKey);
				aadhaarVaultTO.setUid(uid);
				aadhaarVaultTO.setReferenceKey(refKey);
				vaultDao.createRefKeyToAadhaarMapping(aadhaarVaultTO);
			}
			return refKey;
		}
		return refKey;
	}

	@Override
	public ResponseDTO removeAadhaarByReferenceKey(AadhaarNumberRequest request) {
		String refKey = request.getReferenceKey();
		String encryptedRefkey = null;
		ReferenceKeyValidator.validateReferenceKey(refKey);
		AadhaarVaultTO aadhaarVaultTO;

		if (null != hsmEncryptionEnabled && hsmEncryptionEnabled.equalsIgnoreCase("true")) {
			encryptedRefkey = cipherService.encrypt(refKey);
		} else {
			encryptedRefkey = refKey;
		}
		aadhaarVaultTO = vaultDao.getAadhaarVaultData(encryptedRefkey);

		if (null == aadhaarVaultTO) {
			LOGGER.debug("No mapping found for Aadhaar Number with this referenceKey - :{}:", ReferenceMaskUtil.maskPlainReferenceKeyForLog(refKey));
			return new ResponseDTO<>(CommonUtil.getMeta(ResponseErrorCode.NO_AADHAAR_MAPPING_FOUND_FOR_DELETION, DataVaultConstants.REQUEST_FAIL), null);
		}

		if (StringUtils.isEmpty(aadhaarVaultTO.getUid())) {
			LOGGER.debug("Aadhaar Number is already deleted for the referenceKey - :{}:", ReferenceMaskUtil.maskPlainReferenceKeyForLog(refKey));
			return new ResponseDTO<>(CommonUtil.getMeta(ResponseErrorCode.AADHAAR_ALREADY_DELETED, DataVaultConstants.REQUEST_PASS), null);
		}

		if (!vaultDao.removeAadhaarNumberByReferenceKey(encryptedRefkey)) {
			LOGGER.error("Aadhaar Number Not Updated for the referenceKey - :{}:", ReferenceMaskUtil.maskPlainReferenceKeyForLog(refKey));
			throw new DataVaultRuntimeException(ResponseErrorCode.DATA_ACCESS_ERROR);
		}
		return new ResponseDTO<>(CommonUtil.getMeta(ResponseErrorCode.SUCCESS, DataVaultConstants.REQUEST_PASS), null);
	}

	private String generateUniqueRefKey() {
		String checkDigit = null;
		Long seqNo = vaultDao.getNextSeqNumber();
		long[] numbers = generateCantorNumbers(seqNo);
		long cantorNo = AlgorithmUtils.generateCantorUniqueNumber(numbers[0], numbers[1]);
		long number = NUMBER_LIMIT - cantorNo;
		String numberStr = Long.toString(number);
		String luhnCheckDigit = AlgorithmUtils.getLuhnCheckDigit(numberStr);
		String verhoffCheckDigit = AlgorithmUtils.getVerhoeffCheckDigit(numberStr);
		String uniqueNo = null;
		if (luhnCheckDigit.equals(verhoffCheckDigit)) {
			uniqueNo = generateUniqueRefKey();
			return uniqueNo;
		} else {
			checkDigit = luhnCheckDigit;
			uniqueNo = numberStr + checkDigit;
		}
		return uniqueNo;
	}

	private long[] generateCantorNumbers(long seqNo) {
		LOGGER.info("Generating numbers for the seq : {}", seqNo);
		long[] numbers = new long[2];
		numbers[0] = (seqNo / CANTOR_NUMBER_GENERATOR ) + 1;
		numbers[1] = seqNo % CANTOR_NUMBER_GENERATOR;
		return numbers;
	}

}
