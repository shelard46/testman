package com.airtel.orion.datavault.dao;

import com.airtel.orion.datavault.dto.AadhaarVaultTO;

public interface AadhaarVaultDAO {
	
	public String getAadhaarNumber(String refKey);
	
	public String getReferenceKey(String aadhaarNumber);
	
	public boolean createRefKeyToAadhaarMapping(AadhaarVaultTO dataObject);
	
	public Long getNextSeqNumber();

	public boolean removeAadhaarNumberByReferenceKey(String refKey);

	public AadhaarVaultTO getAadhaarVaultData(String refKey);
	
}