package com.airtel.orion.datavault.dao.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.airtel.orion.datavault.dao.ApplicationKeyDAO;
import com.airtel.orion.datavault.dto.ApplicationKeyTO;

@Repository
public class ApplicationKeyDAOImpl implements ApplicationKeyDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private final Logger LOGGER = LoggerFactory.getLogger(getClass());

	@Override
	public String getApplicationKey(String appName) {
		try {
			LOGGER.debug("getting app Key for appName : {} from database", appName);
			String configQuery = "SELECT key FROM application_keys WHERE name = ?";
			String key = jdbcTemplate.queryForObject(configQuery, new Object[] { appName },
					String.class);
			if (!StringUtils.isEmpty(key)) {
				LOGGER.debug("value : {} against appName : {} fetched from database", key,
						appName);
				return key;
			}
			return null;
		} catch (Exception e) {
			LOGGER.error("exception occurred while fetching key from database for appName : {}",
					appName, e);
		}
		return null;
	}

	@Override
	public List<ApplicationKeyTO> getApplicationKeys() {
		try {
			LOGGER.debug("getting app Key from database");
			String configQuery = "SELECT * FROM application_keys";
			List<ApplicationKeyTO> applicationKeys  = jdbcTemplate.query(configQuery,
					new BeanPropertyRowMapper<ApplicationKeyTO>(ApplicationKeyTO.class));
			return applicationKeys;
		} catch (Exception e) {
			LOGGER.error("exception occurred while fetching keys from database :",
					 e);
		}
		return null;
	}

}
