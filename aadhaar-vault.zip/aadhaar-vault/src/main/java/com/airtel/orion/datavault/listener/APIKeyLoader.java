package com.airtel.orion.datavault.listener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.airtel.orion.datavault.constants.DataVaultConstants;
import com.airtel.orion.datavault.dao.ApplicationKeyDAO;
import com.airtel.orion.datavault.dto.ApplicationKeyTO;
import com.airtel.orion.datavault.utils.ApplicationKeyUtil;
import com.airtel.orion.datavault.utils.CipherUtil;

@Component
public class APIKeyLoader implements ApplicationRunner {

	public final Logger LOGGER = LoggerFactory.getLogger(getClass());
	@Autowired
	ApplicationKeyDAO applicationKeyDao;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		try {
			Map<String, String> applicationKeyMap = new HashMap<>();
			List<ApplicationKeyTO> applicationKeys = applicationKeyDao.getApplicationKeys();
			for (ApplicationKeyTO applicationKeyTO : applicationKeys) {
				applicationKeyMap.put(applicationKeyTO.getName(),
						decryptApplicationKey(applicationKeyTO.getKey()));
			}
			ApplicationKeyUtil.setApplicationKeys(applicationKeyMap);
		} catch (Exception e) {
			LOGGER.error("Error while loading application keys in memory", e);
		}

	}

	private String decryptApplicationKey(String appKey) {
		return CipherUtil.decryptData(appKey, DataVaultConstants.PASS_PHRASE);
	}

}
