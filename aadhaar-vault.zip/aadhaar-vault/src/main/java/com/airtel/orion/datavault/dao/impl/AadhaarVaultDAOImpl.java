package com.airtel.orion.datavault.dao.impl;

import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.dao.AadhaarVaultDAO;
import com.airtel.orion.datavault.dto.AadhaarVaultTO;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import com.airtel.orion.datavault.utils.ReferenceMaskUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Repository
public class AadhaarVaultDAOImpl implements AadhaarVaultDAO {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Autowired
    JdbcTemplate aadharJdbcTemplate;

    @Override
    public String getAadhaarNumber(String refKey) {

        try {
            LOGGER.debug("getting aadhaar number for key : {} from database", refKey);
            String configQuery = "SELECT aadhaar_number FROM aadhaar_vault WHERE reference_key = ?";
            List<String> aadharNum = aadharJdbcTemplate.queryForList(configQuery, new Object[]{refKey},
                    String.class);
            if (!CollectionUtils.isEmpty(aadharNum)) {
                LOGGER.debug("aadhaar number value : {} against key : {} fetched from database", aadharNum.get(0),
                        refKey);
                return aadharNum.get(0);
            }
            return null;
        } catch (Exception e) {
            LOGGER.error("Exception occurred while fetching aadaar number from database for key : {}",
                    refKey, e);
            throw new DataVaultRuntimeException(ResponseErrorCode.DATA_ACCESS_ERROR);
        }
    }

    @Override
    public String getReferenceKey(String aadhaarNumber) {

        try {
            LOGGER.debug("getting ref key for aadhaar : {} from database", aadhaarNumber);
            String configQuery = "SELECT reference_key FROM aadhaar_vault WHERE aadhaar_number = ?";
            List<String> refKeys = aadharJdbcTemplate.queryForList(configQuery, new Object[]{aadhaarNumber},
                    String.class);
            if (!CollectionUtils.isEmpty(refKeys)) {
                LOGGER.debug("reference key value : {} against aadhaar number : {} fetched from database",
                        refKeys.get(0), aadhaarNumber);
                return refKeys.get(0);
            }

            return null;
        } catch (Exception e) {
            LOGGER.error("unexpected exception occurred while fetching ref key from database for aadhaar number : {}",
                    aadhaarNumber, e);
            throw new DataVaultRuntimeException(ResponseErrorCode.DATA_ACCESS_ERROR);
        }
    }

    @Override
    public boolean createRefKeyToAadhaarMapping(AadhaarVaultTO dataObject) {
        try {
            LOGGER.debug("storing aadhar vault object {} in database", dataObject);
            String configQuery = "insert into aadhaar_vault (aadhaar_number,reference_key) values (?,?)";
            int rowsInserted = aadharJdbcTemplate.update(configQuery, dataObject.getUid(),
                    dataObject.getReferenceKey());
            LOGGER.debug("stored aadhar vault object {} in database. Result {}", dataObject, rowsInserted);
            if (rowsInserted > 0) {
                return true;
            } else {
                throw new DataVaultRuntimeException(ResponseErrorCode.DATA_ACCESS_ERROR);
            }
        } catch (DataIntegrityViolationException e) {
            LOGGER.error("Database constrainsts violated. Exception occurred while storing value in db : {}",
                    dataObject, e);
            throw new DataVaultRuntimeException(ResponseErrorCode.DATA_CONSTRAINT_VIOLATED);
        } catch (Exception e) {
            LOGGER.error("Exception occurred while storing value in db : {}", dataObject, e);
            throw new DataVaultRuntimeException(ResponseErrorCode.DATA_ACCESS_ERROR);
        }
    }

    @Override
    public Long getNextSeqNumber() {
        String result = "select " + "REF_KEY_SEQ" + ".nextval as num from dual";
        Long seq = aadharJdbcTemplate.queryForObject(result, Long.class);
        return seq;
    }

    @Override
    public boolean removeAadhaarNumberByReferenceKey(String refKey) {
        boolean result = true;
        try {
            LOGGER.debug("Going to Mark the Aadhaar-Nnumber as NULL inside the aadhar vault database for this referenceNumber :{}:", ReferenceMaskUtil.maskEncryptedReferenceKeyForLog(refKey));
            String updateQuery = "update aadhaar_vault set aadhaar_number = ? where reference_key = ?";
            int rowsUpdated = aadharJdbcTemplate.update(updateQuery, null, refKey);
            LOGGER.debug("Updated Aadhaar-Nnumber in database for this referenceNumber  - :{}: | Result - {}", ReferenceMaskUtil.maskEncryptedReferenceKeyForLog(refKey), rowsUpdated);
            if (rowsUpdated <= 0) {
                result = false;
            }
        } catch (Exception e) {
            LOGGER.error("Exception occurred while removing aadhaar number from database for ref key - :{}: | expetion :: {}",
                    ReferenceMaskUtil.maskEncryptedReferenceKeyForLog(refKey), e);
            throw new DataVaultRuntimeException(ResponseErrorCode.DATA_ACCESS_ERROR);
        }
        return result;
    }

    @Override
    public AadhaarVaultTO getAadhaarVaultData(String refKey) {
        AadhaarVaultTO aadhaarVaultData;
        try {
            String query = "select * from aadhaar_vault where reference_key = ?";
            aadhaarVaultData = aadharJdbcTemplate.query(query, new Object[]{refKey}, rs -> {
                if (rs.next()) {
                    AadhaarVaultTO aadhaarVaultTO = new AadhaarVaultTO();
                    aadhaarVaultTO.setUid(rs.getString("aadhaar_number"));
                    aadhaarVaultTO.setReferenceKey(rs.getString("reference_key"));
                    return aadhaarVaultTO;
                } else {
                    return null;
                }
            });
        } catch (Exception e) {
            LOGGER.error("Exception while fetching the aadhaar data from database for ref key :{}:, exception :: {}, {}", ReferenceMaskUtil.maskEncryptedReferenceKeyForLog(refKey), e.getMessage(), e);
            throw new DataVaultRuntimeException(ResponseErrorCode.DATA_ACCESS_ERROR);
        }
        return aadhaarVaultData;
    }

}
