package com.airtel.orion.datavault.adapter.impl;

import java.io.IOException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.security.cert.CertificateException;

import javax.annotation.PostConstruct;
import javax.crypto.SecretKey;

import org.apache.commons.lang.StringUtils;
import org.jasypt.util.text.StrongTextEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.airtel.orion.datavault.adapter.IHSMAdapter;
import com.airtel.orion.datavault.constants.PropertyNames;
import com.airtel.orion.datavault.utils.ConfigMasterUtil;
import com.safenetinc.luna.LunaSlotManager;
import com.safenetinc.luna.exception.LunaException;
import com.safenetinc.luna.provider.LunaProvider;

@Component
@DependsOn("configLoader")
public class HSMAdapterImpl implements IHSMAdapter {

	private static KeyStore lunaKS = null;

	private static String SECURITY_PROVIDER = "LunaProvider";

	private static SecretKey key = null;

	private static int maxRetryAttempts;

	private static int retryAttemptsMade = 0;

	private static boolean isInitialized = false;

	private static final Logger LOGGER = LoggerFactory.getLogger(HSMAdapterImpl.class);

	private static String hsmPassword;

	@Autowired
	private Environment environment;

	private static String passwordEncryptorKey;

	static {
		if (Security.getProvider(SECURITY_PROVIDER) == null) {
			LOGGER.info("Unable to find Luna Security Provider . Inserting it.");
			Security.insertProviderAt(new com.safenetinc.luna.provider.LunaProvider(), 8);
		}
	}

	@PostConstruct
	private void init() {
		passwordEncryptorKey = environment.getProperty("jasypt.password.encryptor.hsm");
	}

	private static KeyStore HSMLogin()
			throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
		LOGGER.info("Logging into HSM ");
		maxRetryAttempts = Integer
				.parseInt(ConfigMasterUtil.getConfigValue(PropertyNames.MAX_HSM_LOGIN_FAILURE_ATTEMPTS));
		String password = getPassword();
		String slotLabel = ConfigMasterUtil.getConfigValue(PropertyNames.HSM_HA_SLOT_LABEL);
		LOGGER.info("Slot Label is {}", slotLabel);
		LunaSlotManager slotm = LunaSlotManager.getInstance();
		slotm.login(slotLabel, password);
		int slotNumber = slotm.findSlotFromLabel(slotLabel);
		LOGGER.info("Slot slotNumber is {}", slotNumber);
		slotm.setSecretKeysExtractable(true);
		lunaKS = KeyStore.getInstance("Luna");
		lunaKS.load(null, null);
		return lunaKS;
	}

	@Override
	public Key getKey() throws Exception {
		LOGGER.info("Fetch Key from HSM ");
		try {
			if (lunaKS == null) {
				lunaKS = HSMLogin();
			}
			String password = getPassword();
			String keyAlias = ConfigMasterUtil.getConfigValue(PropertyNames.KEY_ALIAS_NAME);

			key = (SecretKey) lunaKS.getKey(keyAlias, password.toCharArray());
			isInitialized = true;
		} catch (LunaException e) {
			LOGGER.error("Luna Exception while logging or fetching key from HSM ", e.getMessage(), e);
			lunaKS = null;
			if (!isInitialized && retryAttemptsMade < maxRetryAttempts) {
				LOGGER.error("Retrying to fetch key from HSM. Attempt {}", retryAttemptsMade);
				retryAttemptsMade++;
				getKey();
			} else {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error("Error while fetching key from Luna Keystore :.", e);
			lunaKS = null;
			throw e;
		}
		return key;
	}

	private void HSMLogout() {
		try {
			Security.addProvider(new LunaProvider());
			LunaSlotManager slotm = LunaSlotManager.getInstance();
			slotm.logout();
			slotm.getLunaAPI().Finalize();
		} catch (Exception e) {
			LOGGER.error("Exception while logging out ", e.getMessage(), e);
		}
	}

	private static String getPassword() {
		if(StringUtils.isBlank(hsmPassword)) {
			try {
				String encryptedPassword = ConfigMasterUtil.getConfigValue(PropertyNames.HSM_PASSWORD);
				StrongTextEncryptor strongTextEncryptor = new StrongTextEncryptor();
				strongTextEncryptor.setPassword(passwordEncryptorKey);
				hsmPassword = strongTextEncryptor.decrypt(encryptedPassword);
			} catch (Exception e) {
				LOGGER.error("Unable to decrypt password", e);
			}
		}
		return hsmPassword;
	}

}
