package com.airtel.orion.datavault.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.airtel.orion.datavault.constants.DataVaultConstants;
import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.response.Result;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public final class ResponseEntityBuilder {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseEntityBuilder.class);

	public final <T> ResponseEntity<T> getResponse(T responseObject, ResponseErrorCode responseCode,
			String apiKey) {
		ObjectMapper mapper = new ObjectMapper();
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = responseCode.getHttpStatus();
		if (HttpStatus.OK.equals(status)) {
			String password = ApplicationKeyUtil.getAPIkey(apiKey);
			try {
				String responseBody = mapper.writeValueAsString(responseObject);
				headers.add(DataVaultConstants.SIGNATURE_HEADER,
						CipherUtil.encryptData(String.valueOf(responseBody.hashCode()), password));
			} catch (JsonProcessingException e) {
				LOGGER.error("Json Parsing Exception while building response :: ", e);
				status = HttpStatus.EXPECTATION_FAILED;
			}
		}
		ResponseEntity<T> response = new ResponseEntity<T>(responseObject, headers, status);
		return response;
	}

	public final static Result getResult(ResponseErrorCode responseCode) {
		Result result = new Result();
		result.setStatusCode(responseCode.getStatusCode());
		result.setStatusDescription(responseCode.getMessage());
		return result;
	}
}
