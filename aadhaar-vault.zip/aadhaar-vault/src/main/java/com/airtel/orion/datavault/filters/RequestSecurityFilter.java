package com.airtel.orion.datavault.filters;

import java.io.IOException;

import javax.naming.AuthenticationException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.filter.OncePerRequestFilter;

import com.airtel.orion.datavault.constants.DataVaultConstants;
import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;
import com.airtel.orion.datavault.request.AadhaarNumberRequest;
import com.airtel.orion.datavault.response.Result;
import com.airtel.orion.datavault.utils.ApplicationKeyUtil;
import com.airtel.orion.datavault.utils.CipherUtil;
import com.airtel.orion.datavault.utils.ResponseEntityBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RequestSecurityFilter extends OncePerRequestFilter {

	@Value("${orion.datavault.security.request.filter.enabled}")
	private String isRequestFilterEnable;

	@Autowired
	ObjectMapper mapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(RequestSecurityFilter.class);

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String decryptedHashcode = null;
		RequestWrapper requestWrapper = null;
		try {
			if ("1".equalsIgnoreCase(isRequestFilterEnable)) {
				String context = request.getRequestURI();
				requestWrapper = new RequestWrapper(request);
				String requestPayload = requestWrapper.getPayload();
				AadhaarNumberRequest requestObj = mapper.readValue(requestPayload, AadhaarNumberRequest.class);
				String apiKey = requestObj.getApiKey();
				String securityHeader = request.getHeader(DataVaultConstants.SIGNATURE_HEADER);
				LOGGER.info("Inside RequestSecurityFilter for {} Request Header is:{} for channel {}", context, securityHeader, apiKey);
				if (StringUtils.isEmpty(securityHeader)) {
					setResponse(response, ResponseErrorCode.NO_MSG_SIGNATURE);
					return ;
				} else {
					String password = ApplicationKeyUtil.getAPIkey(apiKey);
					if (StringUtils.isEmpty(password)) {
						setResponse(response, ResponseErrorCode.APP_NOT_REGISTERED);
						return;
					}
					decryptedHashcode = CipherUtil.decryptData(securityHeader.trim(), password);
				}

				if (!String.valueOf(requestPayload.hashCode()).equals(decryptedHashcode)) {
					setResponse(response, ResponseErrorCode.AUTHENTICATION_FAILED);
					return;
				}
				filterChain.doFilter(requestWrapper, response);
			} else {
				filterChain.doFilter(request, response);
			}
		} catch (AuthenticationException e) {
			setResponse(response, ResponseErrorCode.AUTHENTICATION_FAILED);
			LOGGER.error("Exception occurred while authentication {}", e);
			return;
		} catch(DataVaultRuntimeException e){
			setResponse(response, e.getErrorCode());
			LOGGER.error("Exception occurred due to while authentication {}", e.getMessage(), e);
		} catch (Exception e) {
			setResponse(response, ResponseErrorCode.AUTHENTICATION_FAILED);
			LOGGER.error("Exception occurred while authentication {}", e);
			return;
		}
	}

	private HttpServletResponse setResponse(HttpServletResponse response, ResponseErrorCode responseCode)
			throws IOException {
		response.setStatus(responseCode.getHttpStatus().value());
		Result result = ResponseEntityBuilder.getResult(responseCode);
		response.getWriter().write(mapper.writeValueAsString(result));
		return response;
	}

}
