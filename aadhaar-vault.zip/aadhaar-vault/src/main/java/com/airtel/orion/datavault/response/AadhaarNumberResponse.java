package com.airtel.orion.datavault.response;

import com.airtel.orion.datavault.utils.AadhaarMaskUtil;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.io.Serializable;

@JsonPropertyOrder({ "result","requestId", "uid"})
public class AadhaarNumberResponse implements Serializable {

	private static final long serialVersionUID = -2838185298484017104L;

	private Result result;

	private String requestId;

	private String uid;

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("uid", AadhaarMaskUtil.maskAadhaarForLog(uid))
				.append("requestId", requestId).append("result",result.toString()).toString();
	}

}
