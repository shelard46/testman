package com.airtel.orion.datavault.utils;

import java.util.regex.Matcher;

import com.airtel.orion.datavault.constants.DataVaultConstants;
import com.airtel.orion.datavault.constants.PropertyNames;
import com.airtel.orion.datavault.constants.ResponseErrorCode;
import com.airtel.orion.datavault.exceptions.DataVaultRuntimeException;


public class AadhaarValidator {

	public static boolean validateAadhaarNumber(String number) {
		if (number == null || number.length() == 0) {
			throw new DataVaultRuntimeException(ResponseErrorCode.INVALID_UID);
		}
		if (!validateDigitPattern(number)) {
			throw new DataVaultRuntimeException(ResponseErrorCode.INVALID_PATTERN_UID);
		}
		if (!validateNoOfDigits(number)) {
			throw new DataVaultRuntimeException(ResponseErrorCode.INVALID_DIGITS_UID);
		}
		
		if ("1".equals(ConfigMasterUtil.getConfigValue(PropertyNames.VALIDATE_UID_CHECK_DIGIT))) {
			if (!validateCheckDigit(number)) {
				throw new DataVaultRuntimeException(ResponseErrorCode.INVALID_CHECK_DIGIT_UID);
			}
		}
		
		return true;
	}

	private static boolean validateCheckDigit(String number) {
		char checkDigit = number.charAt(number.length() - 1);
		String digit = AlgorithmUtils.getVerhoeffCheckDigit(number.substring(0, number.length() - 1));
		return checkDigit == digit.charAt(0);
	}

	private static boolean validateDigitPattern(String number) {
		Matcher matcher = DataVaultConstants.DIGIT_PATTERN.matcher(number);
		return matcher.matches();
	}

	private static boolean validateNoOfDigits(String number) {
		return (number.length() == DataVaultConstants.AADHAAR_NUMBER_LENGTH); 	
	}


}
