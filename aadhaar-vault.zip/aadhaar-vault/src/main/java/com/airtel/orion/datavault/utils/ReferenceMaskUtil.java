package com.airtel.orion.datavault.utils;

import org.apache.commons.lang.StringUtils;

/**
 * @author Hitesh Khatri
 * @date 02/07/21
 */
public class ReferenceMaskUtil {

    private static final String REF_PLAIN_REGEX = "\\d(?=\\d{4})";
    private static final String REF_ENC_REGEX = ".(?=.{8})";

    public static String maskPlainReferenceKeyForLog(String refKey) {
        String aadhaarRegexValue = "X";
        if (StringUtils.isNotEmpty(refKey)) {
            return refKey.replaceAll(REF_PLAIN_REGEX, aadhaarRegexValue);
        }
        return refKey;
    }

    public static String maskEncryptedReferenceKeyForLog(String refKey) {
        String aadhaarRegexValue = "X";
        if (StringUtils.isNotEmpty(refKey)) {
            return refKey.replaceAll(REF_ENC_REGEX, aadhaarRegexValue);
        }
        return refKey;
    }
}
