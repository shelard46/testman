package com.airtel.orion.datavault.dao;

import java.util.List;

import com.airtel.orion.datavault.dto.ApplicationKeyTO;

public interface ApplicationKeyDAO {
	
	public String getApplicationKey(String appName);

	List<ApplicationKeyTO> getApplicationKeys();

}
