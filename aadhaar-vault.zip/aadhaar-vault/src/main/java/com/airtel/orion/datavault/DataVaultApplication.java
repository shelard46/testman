package com.airtel.orion.datavault;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableEncryptableProperties
//@PropertySources({ @PropertySource(value = "file:${datavault.property.file.path}", ignoreResourceNotFound = true) })
public class DataVaultApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(DataVaultApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder springApplicationBuilder) {
		return springApplicationBuilder.sources(DataVaultApplication.class);
	}

	@Bean
    MeterRegistryCustomizer<MeterRegistry> metricsCommonTags() {
        return registry -> registry.config().commonTags("application", "Data-vault-microservice","vertical","BOP");
    }

}
