package com.airtel.orion.datavault.response;

import java.io.Serializable;

import com.airtel.orion.datavault.utils.ReferenceMaskUtil;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "result", "requestId", "referenceKey"})
public class ReferenceKeyResponse implements Serializable{
	
	private static final long serialVersionUID = 4480842626055714809L;

	private Result result;

	private String requestId;

	private String referenceKey;

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getReferenceKey() {
		return referenceKey;
	}

	public void setReferenceKey(String referenceKey) {
		this.referenceKey = referenceKey;
	}
	
	@Override
	public String toString() {
		return new ToStringBuilder(this).append("referenceKey", ReferenceMaskUtil.maskPlainReferenceKeyForLog(referenceKey)).append("requestId", requestId)
				.append("result", result.toString()).toString();
	}

}
